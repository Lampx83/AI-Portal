-- Chạy khi cài (Admin). Portal thay __SCHEMA__ bằng tên schema (đã trích dẫn) = alias app.
CREATE SCHEMA IF NOT EXISTS __SCHEMA__;

CREATE TABLE IF NOT EXISTS __SCHEMA__.notes (
  id          bigint GENERATED ALWAYS AS IDENTITY PRIMARY KEY,
  user_id     uuid NOT NULL,
  body        text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS notes_user_idx ON __SCHEMA__.notes (user_id, created_at DESC);
